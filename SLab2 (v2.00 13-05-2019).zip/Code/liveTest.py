'''
liveTest.py
'''

import slab

slab.connect()

slab.realtimePlot()
