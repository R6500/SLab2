Documentation for SLab installation

SLab Windows Installation (vx.y).pdf
Installation instructions for Windows systems

SLab Linux Installation (vx.y).pdf
Installation instructions for Linux systems
