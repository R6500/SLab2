import slab
slab.setFilePrefix('../Code/')
slab.setCalPrefix('Calibrations/')
slab.interactive = True
slab.message(1,'Return to interactive mode')
print()

