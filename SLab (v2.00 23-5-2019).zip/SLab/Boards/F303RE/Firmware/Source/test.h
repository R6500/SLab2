/**************************************************************************

 SLab v2
 File: test.h

 Test module header code

 **************************************************************************/

#ifdef USE_TEST
#ifndef TEST_MODULE
#define TEST_MODULE

/* Public functions */

void testGPT(void);


#endif //TEST_MODULE
#endif //USE_TEST
