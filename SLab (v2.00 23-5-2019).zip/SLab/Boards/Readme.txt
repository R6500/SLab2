Currently there are only two supported Hardware Boards

STM32F303RE Nucleo64
This is the prefered board for SLab and the one that
features a better firmware.

STM32L152RE Nucleo64
This board has worse specifications and the provided
firmware is less powerfull.
Not recommended for new systems.
