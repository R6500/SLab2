This folder contains the Python code associated to non standard modules
It includes all the SLab modules and some additional complementary modules.

SLab modules:
  SLab (Main)
  ac
  dc
  fft
  meas
  ez (Deprecated) 

Complementary modules:
  calc
  linear
