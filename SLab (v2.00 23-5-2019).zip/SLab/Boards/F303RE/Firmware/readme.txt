=======================================================
 SLab v2.0
=======================================================
 Firmware Folder Contents
=======================================================

This folder contains the firmware of STM32F303RE Nucleo64 hardware board

It contains the following text files:

   readme.txt : The file you are reading
  license.txt : Slab Firmware license information

It contains the following subfolders:

Bin : Binary firmware for the board
      It the case of the Nucleo boards it is drag and drop

        SLab-Nucleo64-F303RE-2.0.bin
        Firmware for the STM32 Nucleo64 F303RE Board

Source : Source code for the firmware 

