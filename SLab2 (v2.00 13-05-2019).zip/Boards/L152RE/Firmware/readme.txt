=======================================================
 SLab v1.2 (11/2/2018)
=======================================================
 Firmware Folder Contents
=======================================================

This folder contains the firmware for the STM32L152RE Nucleo64 board

This firmware is no longer updated.
The firmware for the STM32F303RE Nucleo64 board is more up to date

It contains the following text files:

   readme.txt : The file you are reading
  license.txt : Slab Firmware license information

It contains the following subfolders:

Bin : Binary firmware for the board
      It the case of the Nucleo boards it is drag and drop

        SLAB-Nucleo64-L152RE-1.2 (2018-02-11).bin
        Firmware for the STM32 Nucleo64 F303RE Board

Source : Source code for the firmware 

