export PYTHONPATH=~/SLab/Code
cd ~/SLab/Jupyter
jupyter notebook

