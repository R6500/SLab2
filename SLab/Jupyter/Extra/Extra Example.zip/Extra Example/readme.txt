--------------------------------
 Example of SLab Extra notebook
--------------------------------

Uncompress this file inside the  SLab/Jupyter/Extra folder

Then, use the Jupyter file explorer to navigate to the "Extra" folder, 
enter the "Extra Example" folder and open the "Extra Example.ipynb" notebook.


